# copy-files
This project will copy files stored in disk drive and paste in the project folder. Project was completed in netbeans ide.
